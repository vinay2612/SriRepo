package Search.Search;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class DataAccessTickets {File m_stFileName;
static String m_stJSONFileName;
static HashMap<Long,String> hMap1=new HashMap<Long,String>();
static HashMap<String,ArrayList<String>> hMap2=new HashMap<String,ArrayList<String>>();
static HashMap<String,String> hMap3=new HashMap<String,String>();
static String[] aStTicket= {"_id","url","external_id","created_at",
	    "type","subject","description","priority","status",
	    "submitter_id","assignee_id","organization_id","tags",
	    "has_incidents","due_at","via"};


public DataAccessTickets(String stJSONFile)
{ 
	 m_stJSONFileName = stJSONFile;
}
public static void load()
   {
	// System.out.println(m_stJSONFileName);
	 	
       //JSON parser object to parse read file
       JSONParser jsonParser = new JSONParser();
       
       try (FileReader reader = new FileReader(m_stJSONFileName))
       {
           //Read JSON file
       	
       		Object obj = jsonParser.parse(reader);

           JSONArray ticketList = (JSONArray) obj;
           //System.out.println(orgList);
            
           //Iterate over employee array
           
           ticketList.forEach( ticket -> parseTicketObject( (JSONObject) ticket ) );

       } catch (FileNotFoundException e) {
           e.printStackTrace();
          
       } catch (IOException e) {
           e.printStackTrace();
           
       } catch (ParseException e) {
       	
           e.printStackTrace();
           
       }
       DataLogic dLogic=new DataLogic(true);
       
   }

   private static void parseTicketObject(JSONObject ticket)
   {
       //Get employee object within list
       //JSONObject employeeObject = (JSONObject) employee.get("employee");
   	
   	StringBuilder sb=new StringBuilder();
   	
   	for(int i=0;i<aStTicket.length;i++)
   	{
   		sb.append(aStTicket[i]).append("\t").append(ticket.get(aStTicket[i]));
   		sb.append("\n");
   		//Long idValue=(Long) organisation.get("_id");
   		//System.out.println(idValue);
	    		try {
	    			if(ticket.get(aStTicket[i]).toString() != null)
	    		{
	    			//System.out.println(organisation.get(aStOrg[i]).toString());
	    				if(!hMap2.containsKey(aStTicket[i]+ticket.get(aStTicket[i]).toString()))
	    			{
	    				hMap2.put(aStTicket[i]+ticket.get(aStTicket[i]).toString(),new ArrayList<String>());
	    			}
	    			hMap2.get(aStTicket[i]+ticket.get(aStTicket[i]).toString()).add((String) ticket.get("_id"));
	    		}
	    		}
   		catch(NullPointerException e)
   		{
   			
   		}
   		
   	}
   	hMap3.put((String)ticket.get("_id"),sb.toString());
   	
   }
}


