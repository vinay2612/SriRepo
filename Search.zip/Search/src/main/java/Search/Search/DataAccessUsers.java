package Search.Search;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class DataAccessUsers {
	
	 File m_stFileName;
	 static String m_stJSONFileName;
	 static HashMap<Long,String> hMap1=new HashMap<Long,String>();
	 static HashMap<String,ArrayList<Long>> hMap2=new HashMap<String,ArrayList<Long>>();
	 static HashMap<Long,String> hMap3=new HashMap<Long,String>();
	 static String[] aStUsers= {"_id","url","external_id","name","alias",
			    "created_at","active","verified","shared","locale","timezone",
			    "last_login_at","email","phone","signature","organization_id","tags",
			    "suspended","role"};
	 
	 
	 public DataAccessUsers(String stJSONFile)
	 {
		 
		 m_stJSONFileName = stJSONFile;
	 }
	 public static void load()
	    {
		// System.out.println(m_stJSONFileName);
		 	
	        //JSON parser object to parse read file
	        JSONParser jsonParser = new JSONParser();
	        
	        try (FileReader reader = new FileReader(m_stJSONFileName))
	        {
	            //Read JSON file
	        	
	        	Object obj = jsonParser.parse(reader);
	 
	            JSONArray usersList = (JSONArray) obj;
	            //System.out.println(orgList);
	             
	            //Iterate over employee array
	            
	            usersList.forEach( users -> parseOrganisationObject( (JSONObject) users ) );
	 
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	           
	        } catch (IOException e) {
	            e.printStackTrace();
	            
	        } catch (ParseException e) {
	        	
	            e.printStackTrace();
	            
	        }
	        
	    }
	 
	    private static void parseOrganisationObject(JSONObject organisation)
	    {
	        //Get employee object within list
	        //JSONObject employeeObject = (JSONObject) employee.get("employee");
	    	
	    	StringBuilder sb=new StringBuilder();
	    	
	    	for(int i=0;i<aStUsers.length;i++)
	    	{
	    		sb.append(aStUsers[i]).append("\t").append(organisation.get(aStUsers[i]));
	    		sb.append("\n");
	    		Long idValue=(Long) organisation.get("_id");
	    		//System.out.println(idValue);
		    		try {
		    			if(organisation.get(aStUsers[i]).toString() != null)
		    		{
		    			//System.out.println(organisation.get(aStOrg[i]).toString());
		    			if(!hMap2.containsKey(aStUsers[i]+organisation.get(aStUsers[i]).toString()))
		    			{
		    				
		    				hMap2.put(aStUsers[i]+organisation.get(aStUsers[i]).toString(),new ArrayList<Long>());
		    			}
		    			
		    			hMap2.get(aStUsers[i]+organisation.get(aStUsers[i]).toString()).add(idValue);
		    		}
		    		}
	    		catch(NullPointerException e)
	    		{
	    			
	    		}
	    		
	    	}
	    	hMap3.put((Long)organisation.get("_id"),sb.toString());
	    	
	    }
	}


