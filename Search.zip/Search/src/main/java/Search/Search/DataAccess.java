package Search.Search;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class DataAccess {
	
	String m_stName;
	 File m_stFileName;
	 static String m_stJSONFileName;
	 static HashMap<Long,String> hMap1=new HashMap<Long,String>();
	 static HashMap<String,ArrayList<Long>> hMap2=new HashMap<String,ArrayList<Long>>();
	 static HashMap<Long,String> hMap3=new HashMap<Long,String>();
	 static String[] aStOrg= {"_id","url","external_id","name","domain_names",
			    "created_at","details","shared_tickets","tags"};
	 
	 
	 public DataAccess(String stJSONFile)
	 {
		 
		 m_stJSONFileName = stJSONFile;
	 }
	 public static void load()
	    {
		// System.out.println(m_stJSONFileName);
		 	
	        //JSON parser object to parse read file
	        JSONParser jsonParser = new JSONParser();
	        
	        try (FileReader reader = new FileReader(m_stJSONFileName))
	        {
	            //Read JSON file
	        	
	        	Object obj = jsonParser.parse(reader);
	 
	            JSONArray orgList = (JSONArray) obj;
	            //System.out.println(orgList);
	             
	            //Iterate over employee array
	            
	            orgList.forEach( org -> parseOrganisationObject( (JSONObject) org ) );
	 
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	           
	        } catch (IOException e) {
	            e.printStackTrace();
	           
	        } catch (ParseException e) {
	        	
	            e.printStackTrace();
	           
	        }
	        DataLogic dLogic=new DataLogic(true);
	        
	    }
	 
	    private static void parseOrganisationObject(JSONObject organisation)
	    {
	        //Get employee object within list
	        //JSONObject employeeObject = (JSONObject) employee.get("employee");
	    	
	    	StringBuilder sb=new StringBuilder();
	    	
	    	for(int i=0;i<aStOrg.length;i++)
	    	{
	    		sb.append(aStOrg[i]).append("\t").append(organisation.get(aStOrg[i]));
	    		sb.append("\n");
	    		Long idValue=(Long) organisation.get("_id");
	    		//System.out.println(idValue);
		    		try {
		    			if(organisation.get(aStOrg[i]).toString() != null)
		    		{
		    			//System.out.println(organisation.get(aStOrg[i]).toString());
		    				if(!hMap2.containsKey(aStOrg[i]+organisation.get(aStOrg[i]).toString()))
		    			{
		    				hMap2.put(aStOrg[i]+organisation.get(aStOrg[i]).toString(),new ArrayList<Long>());
		    			}
		    			hMap2.get(aStOrg[i]+organisation.get(aStOrg[i]).toString()).add(idValue);
		    		}
		    		}
	    		catch(NullPointerException e)
	    		{
	    			
	    		}
	    		
	    	}
	    	hMap3.put((Long)organisation.get("_id"),sb.toString());
	    	
	    }
	}