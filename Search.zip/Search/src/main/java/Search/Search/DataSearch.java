package Search.Search;
import java.io.File;
import java.util.Scanner;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
public class DataSearch {

	public static void main(String[] aSt) {
		// TODO Auto-generated method stub
		
		 final String APP_NAME = "DataSearch";

	        /*Options options = new Options();

	        Option help = new Option("h", "help", false, "print this message");
	        Option organisation = new Option("o", "organisation", false, "Searches the organisation.json.  Params:idName fileOutput");
	        Option ticket = new Option("t", "tickets", false, "Searches the tickets.json.  Params:idName fileOutput");
	        Option users = new Option("u", "users", false, "Searches the user.json.  Params:idName fileOutput");
	        options.addOption(help);
	        options.addOption(organisation);
	        options.addOption(ticket);
	        options.addOption(users);
	        CommandLineParser parser = new BasicParser();*/
	        
	        try
	        {
	        	String stId="_id";
	        	
	        	Scanner sc=new Scanner(System.in);
	        	String stJSONFile="C:\\Homework\\organizations.json";
	        	String stJSONFileUsers="C:\\Homework\\users.json";
	        	String stJSONFileTickets="C:\\Homework\\tickets.json";
	          
	        	DataLogic data = new DataLogic(stJSONFile,stJSONFileUsers,stJSONFileTickets);	
	            data.store();
	      
	      //  	 CommandLine line = parser.parse(options, aSt);

	        //     if (line.hasOption("help") || (line.getArgs() == null || line.getArgs().length == 0)) {
	          //       HelpFormatter formatter = new HelpFormatter();
	            //     formatter.printHelp(APP_NAME, options);
	              //   return;
	             //}
	        	int op;
	        	do
	        	{
	        		System.out.println("Select Search Options");
	        		System.out.println("press 1 to search Zendesk");
	        		System.out.println("press 2 to search a ist of searchable fields");
	        		System.out.println("press 3 to quit");
	        		
	        		op=sc.nextInt();
	        		if(op==1)
	        		{
	        			System.out.println("Press a for users");
	        			System.out.println("Press b for tickets");
	        			System.out.println("Press c for organisation");
	        			char type=sc.next().charAt(0);
	        			if(type=='a')
	        			{
	        				
	        				System.out.println("enter the search cretira");
	        				Scanner sc2=new Scanner(System.in);
		        			String stSrchCriteria=sc2.nextLine();
		        			System.out.println("criteria is "+stSrchCriteria);
		        			System.out.println("Enter the criteria value");
		        			String stValue=sc2.nextLine();
		        			DataLogic dLogic=new DataLogic(stSrchCriteria,stValue);
		        			if(stSrchCriteria.equalsIgnoreCase(stId))
		        			{
		        				String stResult=DataLogic.retriveUsersUsingId(stValue);
		        				System.out.println(stResult);
		        			}
		        			else
		        			{
		        				
			        			
			        			String[] aStResult2=DataLogic.retriveUsersUsingOtherFields(stSrchCriteria,stValue);
			        			for(int i=0;i<aStResult2.length;i++)
			        			{
			        				System.out.println(aStResult2[i]);
			        				System.out.println();
			        			}
		        			}
	        				
	        			}
	        			else if(type=='b')
	        			{
	        			
	        				System.out.println("enter the search cretira");
	        				Scanner sc2=new Scanner(System.in);
		        			String stSrchCriteria=sc2.nextLine();
		        			System.out.println("criteria is "+stSrchCriteria);
		        			System.out.println("Enter the criteria value");
		        			String stValue=sc2.nextLine();
		        			DataLogic dLogic=new DataLogic(stSrchCriteria,stValue);
		        			if(stSrchCriteria.equalsIgnoreCase(stId))
		        			{
		        				String stResult=DataLogic.retriveTicketsUsersUsingId(stValue);
		        				System.out.println(stResult);
		        			}
		        			else
		        			{
			        			
			        			String[] aStResult2=DataLogic.retriveTicketsUsingOtherFields(stSrchCriteria,stValue);
			        			for(int i=0;i<aStResult2.length;i++)
			        			{
			        				System.out.println(aStResult2[i]);
			        				System.out.println();
			        			}
		        			}
	        				
	        			}
	        			else if(type=='c')
	        			{
	        				
	        				System.out.println("enter the search cretira");
	        				Scanner sc2=new Scanner(System.in);
		        			String stSrchCriteria=sc2.nextLine();
		        			System.out.println("criteria is "+stSrchCriteria);
		        			System.out.println("Enter the criteria value");
		        			String stValue=sc2.nextLine();
		        			DataLogic dLogic=new DataLogic(stSrchCriteria,stValue);
		        			if(stSrchCriteria.equalsIgnoreCase(stId))
		        			{
		        				String stResult=DataLogic.retriveUsingId(stValue);
		        				System.out.println(stResult);
		        			}
		        			else
		        			{
			        			
			        			String[] aStResult2=DataLogic.retriveUsingOtherFields(stSrchCriteria,stValue);
			        			for(int i=0;i<aStResult2.length;i++)
			        			{
			        				System.out.println(aStResult2[i]);
			        				System.out.println();
			        			}
		        			}
	        				
	        			}
	        		}
	        			
	        			
	        		else if(op==2)
		        		{
		        			String[] aStOrg= {"_id","url","external_id","name","alias","created_at","active","verified","shared"};
		        			String[] aStTickets= {"_id","url","external_id","created_at",
		        				    "type","subject","description","priority","status",
		        				    "submitter_id","assignee_id","organization_id","tags",
		        				    "has_incidents","due_at","via"};
		        			String[] aStUsers= {"_id","url","external_id","name","alias",
		        				    "created_at","active","verified","shared","locale","timezone",
		        				    "last_login_at","email","phone","signature","organization_id","tags",
		        				    "suspended","role"};
		        			
		        			System.out.println("Search organisation with");
		        			for(int i=0;i<aStOrg.length;i++)
		        			{
		        				System.out.println(aStOrg[i]);
		        			}
		        			System.out.println("\n");
		        			
		        			System.out.println("Search tickets with");
		        			for(int i=0;i<aStTickets.length;i++)
		        			{
		        				System.out.println(aStTickets[i]);
		        			}
		        			
		        			System.out.println("\n");
		        			System.out.println("Search users with");
		        			
		        			for(int i=0;i<aStUsers.length;i++)
		        			{
		        				System.out.println(aStUsers[i]);
		        			}
		        		}
		        	}while(op!=3);
		        	
		            
		        	
		        }
		        catch (Throwable t) {
		            t.printStackTrace();
		        }
		}
	}
