package Search.Search;

import java.io.File;
import java.util.ArrayList;

public class DataLogic {
	
	String m_stCriteria;
	String m_stValue;
	String m_stJSONFile;
	String m_stJSONFileUsers;
	String m_stJSONFileTickets;
	
	
	public DataLogic(String stCriteria,String stValue)
	{
		m_stCriteria=stCriteria;
		m_stValue=stValue;
		
	}
	
	public DataLogic(String stJSONFile,String stJSONFileUsers,String stJSONFileTickets)
	{
		m_stJSONFile=stJSONFile;
		m_stJSONFileUsers=stJSONFileUsers;
		m_stJSONFileTickets=stJSONFileTickets;
	}
	
	public DataLogic(boolean m_fLoad)
	{
		m_fLoad=true;
	}

	public void store() {
		// TODO Auto-generated method stub
		DataAccess dAccess=new DataAccess(m_stJSONFile);
		DataAccessUsers dAccessUsers=new DataAccessUsers(m_stJSONFileUsers);
		DataAccessTickets dAccessTickets=new DataAccessTickets(m_stJSONFileTickets);
		dAccess.load();
		dAccessUsers.load();
		dAccessTickets.load();
		
	}
	
	public static String retriveUsingId(String stValue)

	{
		Long id=Long.valueOf(stValue);
		return DataAccess.hMap3.get(id);
	}

	public static String[] retriveUsingOtherFields(String stSrchCriteria,String stValue) {
		// TODO Auto-generated method stub
		try
		{
		
		ArrayList<Long> list1=DataAccess.hMap2.get(stSrchCriteria+stValue);
		System.out.println("Total Count "+list1.size());
		String[] aStRes=new String[list1.size()];
		for(int i=0;i<list1.size();i++)
		{
			Long id=Long.valueOf(list1.get(i));
			aStRes[i]=DataAccess.hMap3.get(id);
			
			
		}
		return aStRes;
		}
		catch(NullPointerException e)
		{
			return null;
		}
		
	}

	public static String retriveUsersUsingId(String stValue) {
		// TODO Auto-generated method stub
		Long id=Long.valueOf(stValue);
		return DataAccessUsers.hMap3.get(id);
	}

	public static String[] retriveUsersUsingOtherFields(String stSrchCriteria, String stValue) {
		// TODO Auto-generated method stub
		try
		{
			
		
		ArrayList<Long> list1=DataAccessUsers.hMap2.get(stSrchCriteria+stValue);
		System.out.println("Total Count "+list1.size());
		System.out.println(list1.size());
		String[] aStRes=new String[list1.size()];
		for(int i=0;i<list1.size();i++)
		{
			Long id=Long.valueOf(list1.get(i));
			aStRes[i]=DataAccessUsers.hMap3.get(id);
			
			
		}
		return aStRes;
		}
		catch(NullPointerException e)
		{
			return null;
		}
	}

	public static String retriveTicketsUsersUsingId(String stValue) {
		// TODO Auto-generated method stub
		
		return DataAccessTickets.hMap3.get(stValue);
	}

	public static String[] retriveTicketsUsingOtherFields(String stSrchCriteria, String stValue) {
		// TODO Auto-generated method stub
		try
		{
		ArrayList<String> list1=DataAccessTickets.hMap2.get(stSrchCriteria+stValue);
		System.out.println("Total Count "+list1.size());
		
		String[] aStRes=new String[list1.size()];
		for(int i=0;i<list1.size();i++)
		{
			String id=list1.get(i);
			System.out.println("id"+id);
			aStRes[i]=DataAccessTickets.hMap3.get(id);
			
			
		}
		return aStRes;
		}
		catch(NullPointerException e)
		{
			return null;
		}
	}

	

}
